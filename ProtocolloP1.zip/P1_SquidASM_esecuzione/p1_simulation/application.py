import ast
import random

from netqasm.sdk import Qubit
from squidasm.sim.stack.program import Program, ProgramContext, ProgramMeta
from squidasm.util.routines import teleport_send, teleport_recv


# Codifica degli stati BB84:
# 0 = |0>, 1 = |1>, 2 = |+>, 3 = |->
ORTHOGONAL = {0: 1, 1: 0, 2: 3, 3: 2}


def prepare_bb84(connection, state):
    q = Qubit(connection)
    if state in (1, 3):
        q.X()
    if state in (2, 3):
        q.H()
    return q


def measure_and_exclude(q, connection):
    """Misura in base Z oppure X ed esclude uno stato BB84."""
    basis_x = random.choice([False, True])
    if basis_x:
        q.H()

    outcome_future = q.measure()
    yield from connection.flush()
    outcome = int(outcome_future)

    if basis_x:
        excluded = 3 if outcome == 0 else 2
    else:
        excluded = 1 if outcome == 0 else 0

    return excluded


class AliceProgram(Program):
    def __init__(self, num_bits=32, message_bit=0, scenario="authentic"):
        if scenario not in ("authentic", "altered", "forgery"):
            raise ValueError(f"Scenario sconosciuto: {scenario}")
        self.num_bits = num_bits
        self.message_bit = message_bit
        self.scenario = scenario

    @property
    def meta(self):
        return ProgramMeta(
            name="p1_alice",
            csockets=["Bob", "Charlie"],
            epr_sockets=["Bob", "Charlie"],
            max_qubits=2,
        )

    def run(self, context: ProgramContext):
        connection = context.connection
        keys = {}

        # Distribuzione: due copie della firma per ciascun messaggio.
        for message in (0, 1):
            keys[message] = [
                random.randrange(4) for _ in range(self.num_bits)
            ]
            for state in keys[message]:
                for peer in ("Bob", "Charlie"):
                    q = prepare_bb84(connection, state)
                    yield from teleport_send(q, context, peer)

        # Attende che entrambi abbiano completato la distribuzione.
        yield from context.csockets["Bob"].recv()
        yield from context.csockets["Charlie"].recv()

        declared_key = list(keys[self.message_bit])

        # Scenario di integrità: Alice invia una dichiarazione alterata.
        # Nello scenario di contraffazione, invece, Alice invia la
        # dichiarazione autentica e Bob tenta di falsificare il messaggio.
        if self.scenario == "altered":
            declared_key = [ORTHOGONAL[x] for x in declared_key]

        context.csockets["Bob"].send(
            repr((self.message_bit, declared_key))
        )

        return {
            "message": self.message_bit,
            "scenario": self.scenario,
            "signature_length": self.num_bits,
        }


class RecipientProgram(Program):
    PEER = None
    OTHER = None
    IS_BOB = False

    def __init__(self, num_bits=32, sa=0.0, sv=0.14, r=0.2):
        self.num_bits = num_bits
        self.sa = sa
        self.sv = sv
        self.r = r

    @property
    def meta(self):
        return ProgramMeta(
            name=f"p1_{self.PEER.lower()}",
            csockets=["Alice", self.OTHER],
            epr_sockets=["Alice"],
            max_qubits=2,
        )

    def run(self, context: ProgramContext):
        records = []
        outgoing = []

        # Misurazione immediata e scambio casuale degli esiti
        # classici. Chi inoltra un esito non lo conserva localmente.
        for message in (0, 1):
            for index in range(self.num_bits):
                q = yield from teleport_recv(context, "Alice")
                excluded = yield from measure_and_exclude(
                    q, context.connection
                )

                record = (message, index, excluded)
                if random.choice([True, False]):
                    outgoing.append(record)
                else:
                    records.append(record)

        # Alice può passare alla fase di messaggistica.
        context.csockets["Alice"].send("READY")

        # Scambio dei risultati classici tra Bob e Charlie.
        context.csockets[self.OTHER].send(repr(outgoing))
        incoming = ast.literal_eval(
            (yield from context.csockets[self.OTHER].recv())
        )
        records.extend(tuple(item) for item in incoming)

        # Controllo del numero di elementi ricevuti per ciascun messaggio.
        # Il protocollo abortisce se il conteggio è fuori da L(1/2 +/- r).
        low = int(self.num_bits * (0.5 - self.r) + 0.999999999)
        high = int(self.num_bits * (0.5 + self.r))
        incoming_counts = {
            message: sum(1 for m, _, _ in incoming if m == message)
            for message in (0, 1)
        }
        local_abort = any(
            not (low <= count <= high)
            for count in incoming_counts.values()
        )

        # Entrambi devono conoscere l'esito del controllo di distribuzione.
        context.csockets[self.OTHER].send(repr(local_abort))
        peer_abort = ast.literal_eval(
            (yield from context.csockets[self.OTHER].recv())
        )
        protocol_abort = bool(local_abort or peer_abort)

        if self.IS_BOB:
            message, declared_key = ast.literal_eval(
                (yield from context.csockets["Alice"].recv())
            )

            mismatches = sum(
                1 for m, i, excluded in records
                if m == message and excluded == declared_key[i]
            )
            accepted = (
                not protocol_abort
                and mismatches <= int(self.sa * self.num_bits)
            )

            # Bob inoltra la dichiarazione ricevuta, salvo lo scenario
            # di contraffazione, nel quale tenta di firmare l'altro bit
            # con una chiave casuale che non conosce.
            forwarded_message = message
            forwarded_key = list(declared_key)
            if getattr(self, "forge", False):
                forwarded_message = 1 - message
                forwarded_key = [
                    random.randrange(4) for _ in range(self.num_bits)
                ]

            context.csockets[self.OTHER].send(
                repr((
                    forwarded_message,
                    forwarded_key,
                    accepted,
                    mismatches,
                    protocol_abort,
                ))
            )

            return {
                "recipient": "Bob",
                "message": message,
                "mismatches": mismatches,
                "accepted": accepted,
                "records_checked": sum(
                    1 for m, _, _ in records if m == message
                ),
                "incoming_counts": incoming_counts,
                "aborted": protocol_abort,
                "forgery_attempt": getattr(self, "forge", False),
                "forwarded_message": forwarded_message,
            }

        (
            message,
            declared_key,
            bob_accepted,
            bob_mismatches,
            forwarded_abort,
        ) = ast.literal_eval(
            (yield from context.csockets[self.OTHER].recv())
        )

        mismatches = sum(
            1 for m, i, excluded in records
            if m == message and excluded == declared_key[i]
        )

        # Verifica indipendente di Charlie: non dipende dall'accettazione
        # di Bob, ma rifiuta se la distribuzione è stata abortita.
        protocol_abort = protocol_abort or bool(forwarded_abort)
        accepted = (
            not protocol_abort
            and mismatches <= int(self.sv * self.num_bits)
        )

        return {
            "recipient": "Charlie",
            "message": message,
            "mismatches": mismatches,
            "accepted": accepted,
            "bob_accepted": bob_accepted,
            "bob_mismatches": bob_mismatches,
            "records_checked": sum(
                1 for m, _, _ in records if m == message
            ),
            "incoming_counts": incoming_counts,
            "aborted": protocol_abort,
        }


class BobProgram(RecipientProgram):
    PEER = "Bob"
    OTHER = "Charlie"
    IS_BOB = True

    def __init__(self, *args, forge=False, **kwargs):
        super().__init__(*args, **kwargs)
        self.forge = forge


class CharlieProgram(RecipientProgram):
    PEER = "Charlie"
    OTHER = "Bob"
    IS_BOB = False
