import random
import sys
from pathlib import Path

from squidasm.run.stack.config import StackNetworkConfig
from squidasm.run.stack.run import run

from application import AliceProgram, BobProgram, CharlieProgram


BASE = Path(__file__).resolve().parent
LENGTHS = [16, 32, 64]
REPETITIONS = 3
SCENARIOS = ["authentic", "altered", "forgery"]
CONDITIONS = ["ideal", "noisy"]
R = 0.2
SV = 0.14


def main():
    completed = 0
    failures = []

    expected = (
        len(LENGTHS) * REPETITIONS * len(SCENARIOS)
        * len(CONDITIONS) * 2
    )
    trial = 0

    for condition in CONDITIONS:
        config_path = BASE / f"config_{condition}.yaml"
        config = StackNetworkConfig.from_file(str(config_path))

        # sa=0 nel caso ideale; sa non nullo nel caso rumoroso.
        sa = 0.0 if condition == "ideal" else 0.10

        for scenario in SCENARIOS:
            for n in LENGTHS:
                for message_bit in (0, 1):
                    for repetition in range(1, REPETITIONS + 1):
                        trial += 1
                        seed = (
                            4200
                            + (0 if condition == "ideal" else 100000)
                            + n * 1000
                            + SCENARIOS.index(scenario) * 100
                            + message_bit * 10
                            + repetition
                        )
                        random.seed(seed)

                        print(
                            f"[{trial}/{expected}] {condition=} "
                            f"{scenario=} L={n} m={message_bit} "
                            f"ripetizione={repetition}",
                            flush=True,
                        )

                        try:
                            programs = {
                                "Alice": AliceProgram(
                                    num_bits=n,
                                    message_bit=message_bit,
                                    scenario=scenario,
                                ),
                                "Bob": BobProgram(
                                    num_bits=n,
                                    sa=sa,
                                    sv=SV,
                                    r=R,
                                    forge=(scenario == "forgery"),
                                ),
                                "Charlie": CharlieProgram(
                                    num_bits=n,
                                    sa=sa,
                                    sv=SV,
                                    r=R,
                                ),
                            }

                            a, b, c = run(
                                config=config,
                                programs=programs,
                                num_times=1,
                            )

                            completed += 1
                            print(
                                "   Bob:", b[0]["accepted"],
                                "| Charlie:", c[0]["accepted"],
                                "| abort:", c[0]["aborted"],
                                "| mismatch C:", c[0]["mismatches"],
                                flush=True,
                            )
                        except Exception as exc:
                            failures.append({
                                "condition": condition,
                                "scenario": scenario,
                                "length": n,
                                "message_bit": message_bit,
                                "repetition": repetition,
                                "error": repr(exc),
                            })
                            print("   ERRORE:", repr(exc), flush=True)

    print("\n========== RIEPILOGO ==========")
    print(f"Prove completate: {completed}/{expected}")
    print(f"Errori di esecuzione: {len(failures)}")

    if failures or completed != expected:
        sys.exit(1)


if __name__ == "__main__":
    main()
